
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sys/time.h>
#include <errno.h>
#define PORT 7
#define MAXLEN 256
#define PAKET 4

int main(int argc, char *argv[]){

	int mysocket;
	struct sockaddr_in servaddr;
	void *msgbuff;
	struct addrinfo hints, *res;
	int options;
	int error;
	int i;
	char tempaddr[100];
	int pflag=0;
	struct timeval tv;
	uint32_t ID;
	
	uint64_t curtime;
	uint64_t curtimeNew;
	uint64_t curtimeTotal;
	uint64_t timeAvg = 0;
	uint32_t brojPaketa = PAKET;
	socklen_t servlen;
	
	if (argc!=2 && argc!=4 && argc!=6 && argc!=8){
		err(3,"Usage: ./rtttklijent [-p port] [-t TTL] [-c broj] server\n");
	}
	
	while ((options = getopt(argc, argv, "p:t:c:")) != -1){
		switch (options){
			case 'p':
				memset(&servaddr,0,sizeof(servaddr));
				memset(&hints, 0 , sizeof (hints));
				hints.ai_family = AF_INET;
				hints.ai_socktype = SOCK_DGRAM;
				hints.ai_flags =  AI_PASSIVE;
				error = getaddrinfo(NULL, optarg, &hints, &res);
				if (error!=0){
					err(1, "%s", gai_strerror(error));
				}
				servaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
				pflag=1;
				break;
			case 't':
				// za implementirati 
				break;
			case 'c':
				brojPaketa = atoi(optarg);
				break;
			default:
				err(3,"Usage: ./rtttklijent [-p port] [-t TTL] [-c broj] server\n");
				break;
		}
	}
	if (pflag==0){
		servaddr.sin_port = htons(PORT);

	}
	mysocket = socket(PF_INET, SOCK_DGRAM, 0);
	if (mysocket==-1){
		err(2, "socket\n");
	}
	
	
	
	
	memset(&hints, 0 , sizeof (hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags=AI_PASSIVE;
	error = getaddrinfo(argv[argc-1], NULL, &hints, &res);
	if (error!=0){
		err(1, "%s", gai_strerror(error));
	}
	servaddr.sin_addr = ((struct sockaddr_in *)res->ai_addr)->sin_addr;
	servaddr.sin_family=AF_INET;
	ID = getpid();
	i=0;
	servlen=sizeof(servaddr);
	printf("#  rtt   IP\n");
	while (i<brojPaketa)  {
		error = gettimeofday(&tv, NULL);
		if (error < 0) {
			err(45, "timeofday\n");
		}
		curtime = tv.tv_sec*1000000+tv.tv_usec;
		//strncat(msgbuff,(char*)ID, sizeof(ID));
		//strncat(msgbuff,(char*)i, sizeof(i));
		//strncat(msgbuff,(char*)curtime, sizeof(curtime));
		msgbuff = (void*)malloc(sizeof(uint32_t)+sizeof(int)+sizeof(uint64_t));
		memset(msgbuff, 0, sizeof(int)+sizeof(uint32_t)+sizeof(uint64_t));
		memcpy(msgbuff, (const void*) &i, sizeof (int));
		memcpy(msgbuff+sizeof(uint32_t), (const void*) &ID, sizeof (uint32_t));
		memcpy(msgbuff+sizeof(uint32_t)*2, (const void*) &curtime, sizeof (uint64_t));
		
		error=sendto(mysocket, msgbuff, strlen(msgbuff)+1, 0, (struct sockaddr *) &servaddr, servlen);
		if (error==-1){
				err(6,"send\n");
		}	
		memset(&msgbuff,0,sizeof(msgbuff));	
		servlen=sizeof(servaddr);
		error=recvfrom(mysocket, msgbuff, MAXLEN, 0, (struct sockaddr *) &servaddr, &servlen);
		if(error==-1){
				err(6,"receve\n");
		}
			
		error = gettimeofday(&tv, NULL);
		if (error < 0) {
			err(45, "timeofday\n");
		}
		curtimeNew = tv.tv_sec*1000000+tv.tv_usec;
		curtimeTotal = curtime - curtimeNew;
		timeAvg += curtimeTotal;
		inet_ntop(AF_INET, &(((struct sockaddr_in *)res->ai_addr)->sin_addr.s_addr), tempaddr, INET_ADDRSTRLEN);
		//printf("%d  %f  %s\n", i, (double)curtimeTotal, (char*)ntohl(servaddr.sin_addr));
		printf ("%d \n",i);
		printf("%f\n", (double)curtimeTotal);
		printf ("%s\n", tempaddr); 
		
		i++;
	}
	timeAvg = timeAvg/brojPaketa;
	printf("%s - Avreage rtt = %f",tempaddr, (double)timeAvg);
	
	return 0;
}
