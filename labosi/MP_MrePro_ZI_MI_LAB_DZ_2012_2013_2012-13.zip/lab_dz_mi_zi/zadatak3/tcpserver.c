#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#define PORT 1234
#define MAXLEN 1400

int main (int argc, char *argv[]){
	int pflag = 0;
	int mysocket;
	int newsocket;
	struct sockaddr_in myaddr;
	char msgbuff[MAXLEN];
	struct addrinfo hints, *res;
	int options;
	int error;
	char filebuffer[MAXLEN];
	ssize_t recvlen;
	FILE *f;
	
	if (argc!=1 && argc!=3){
		err(3,"Usage: ./tcpserver [-p port]");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./tcpserver [-p port]");
				break;
		}
	}
	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	if (mysocket==-1){
		err(2, (char*)errno);
	}

	if (pflag){
		memset(&hints, 0 , sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags |= AI_CANONNAME;
		error = getaddrinfo(NULL, optarg, &hints, &res);
		if (error!=0){
			err(1, "%s", gai_strerror(error));
		}
		myaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
	}else{
		myaddr.sin_port = htons(PORT);
	}
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	memset(myaddr.sin_zero, '\0', sizeof(myaddr.sin_zero));
	error = bind(mysocket,(struct sockaddr *) &myaddr, sizeof(myaddr));
	if ( error!=0){
		printf("Port not availalbe\n");
		return 4;
	}
	error = listen(mysocket,1);
	if (error == -1){
		err(4, (char*)errno);
	}
	while (1){
		newsocket=accept(mysocket, NULL, NULL);
		if (newsocket == -1){
			err(5,(char*)errno);
		}
		recvlen = recv(newsocket, msgbuff, sizeof(msgbuff), 0);
		if (recvlen == -1) {
			err(7,"receve");
		}
		if (! strcmp(msgbuff,"Kraj")){
			
			close(newsocket);
			close(mysocket);
			return 0;
		}
		if (strchr(msgbuff, '/')){
			close(newsocket);
			close(mysocket);
			err(9,"Datoteka izvan trenutnog direktorija\n");
		}
		f = fopen(msgbuff, "rb");
		if (f == NULL){
			close(newsocket);
			close(mysocket);
			err(10,"Datoteka ne postoji\n");
		}
	
		
		while(!feof(f)){
			memset(filebuffer, '\0', sizeof(filebuffer));
			int procitano = fread (filebuffer, sizeof (char), MAXLEN, f);
			if (procitano < 0 ) {
				errx(-1, "fread()");
			}
			error = send(newsocket, filebuffer, (sizeof (char))*procitano, 0);
			if (error <0){
				errx(-1,"send()");
			}
		} 
		
		close(newsocket);
		fclose(f);
	}
	return 0;
}
