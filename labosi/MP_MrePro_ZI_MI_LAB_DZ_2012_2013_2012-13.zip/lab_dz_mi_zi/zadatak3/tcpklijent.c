#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#define PORT 1234
#define MAXLEN 1400

int main(int argc, char *argv[]){
	int pflag = 0;
	int mysocket;
	struct sockaddr_in servaddr;
	char msgbuff[MAXLEN];
	struct addrinfo hints, *res;
	int options;
	int error;
	int i;
	ssize_t recvlen;
	int endflag=0;

	
	if (argc!=2 && argc!=4){
		err(3,"Usage: ./tcpklijent [-p port] server_IP\n");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./tcpsklijent [-p port] server_IP\n");
				break;
		}
	}
	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	if (mysocket==-1){
		err(2, (char*)errno);
	}
	memset(&hints, 0 , sizeof (hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags|=AI_CANONNAME;
	error = getaddrinfo(argv[argc-1], NULL, &hints, &res);
	if (error!=0){
		err(1, "%s", gai_strerror(error));
	}
	servaddr.sin_addr = ((struct sockaddr_in *)res->ai_addr)->sin_addr;

	if (pflag){
		memset(&hints, 0 , sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags|=AI_CANONNAME;
		error = getaddrinfo(NULL, optarg, &hints, &res);
		if (error!=0){
			err(1, "%s", gai_strerror(error));
		}
		servaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
	}else{
		servaddr.sin_port = htons(PORT);
	}
	servaddr.sin_family = AF_INET;
	memset(servaddr.sin_zero, '\0', sizeof (servaddr.sin_zero));
	if (connect (mysocket, (struct sockaddr *) &servaddr, sizeof (servaddr)) == -1) {
		err(1,"connect");
	}
	scanf("%s", msgbuff);
	if (send(mysocket, msgbuff, sizeof (msgbuff) +1, 0) == -1){
		err(2,"send");
	}
	
	while (1){
		memset(msgbuff, '\0', sizeof(msgbuff));
		recvlen = recv(mysocket, msgbuff, sizeof(msgbuff), 0);
		switch (recvlen){
			case -1:
				err(3,"receve");
				break;
			case 0:
				endflag = 1;
				
				break;
			default:
				i=0;
				while (i<recvlen){
					printf("%c", msgbuff[i]);
					fflush(stdout);
					i++;
				}
				break;
		} 
		if (endflag){
			break;
		}
	}
	return 0;
}
