#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#define MAXLEN 256
#define S_PORT 1234

int main(int argc, char *argv[]){
	int pflag = 0;
	int mysocket;
	struct sockaddr_in servaddr;
	char msgbuff[MAXLEN];
	socklen_t servlen;
	int msglen;
	struct addrinfo hints, *res;
	int options;
	int error;
	
	if (argc!=2 && argc!=4){
		err(3,"Usage: ./udpklijent [-p port] server_IP\n");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./udpsklijent [-p port] server_IP\n");
				break;
		}
	}
	mysocket = socket(PF_INET, SOCK_DGRAM, 0);
	if (mysocket==-1){
		err(2, (char*)errno);
	}
	memset(&servaddr,0,sizeof(servaddr));
	if (pflag){
		memset(&hints, 0 , sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_DGRAM;
		hints.ai_flags =  AI_PASSIVE;
		error = getaddrinfo(NULL, optarg, &hints, &res);
		if (error!=0){
			err(1, "%s", gai_strerror(error));
		}
		servaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
	}else{
		servaddr.sin_port = htons(S_PORT);
	}
	inet_pton(AF_INET, argv[argc-1], &servaddr.sin_addr);
	servaddr.sin_family=AF_INET;
	while (1){
		servlen=sizeof(servaddr);
		
		msglen=scanf("%s", msgbuff);
		
		if (msglen==EOF){
			error=0;
			error=sendto(mysocket, 0, 0, 0, (struct sockaddr *) &servaddr, servlen);
			if (error==-1){
				err(6,(char*)errno);
			}
			return 0;			
		}else{
			error=0;
			
			error=sendto(mysocket, msgbuff, strlen(msgbuff)+1, 0, (struct sockaddr *) &servaddr, servlen);
			if (error==-1){
				err(6,(char*)errno);
			}
			error=0;
			error=recvfrom(mysocket, msgbuff, MAXLEN, 0, (struct sockaddr *) &servaddr, &servlen);
			if(error==-1){
				err(6,(char*)errno);
			}
			printf("%s\n",msgbuff);
		}
		
	}
	return 0; 
}
