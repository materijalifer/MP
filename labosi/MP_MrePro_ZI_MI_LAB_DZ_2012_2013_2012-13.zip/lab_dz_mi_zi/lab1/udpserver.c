#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#define MAXLEN 256
#define S_PORT 1234

int main(int argc, char *argv[]){
	int pflag = 0;
	int mysocket;
	struct sockaddr_in myaddr, cliaddr;
	char msgbuff[MAXLEN];
	socklen_t clilen;
	int msglen;
	struct addrinfo hints, *res;
	int options;
	int error;
	char tempaddr[100];
	int ipflag = 1;
	int i;
	
	if (argc!=1 && argc!=3){
		err(3,"Usage: ./udpserver [-p port]");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./udpserver [-p port]");
				break;
		}
	}
	mysocket = socket(PF_INET, SOCK_DGRAM, 0);
	if (mysocket==-1){
		err(2, (char*)errno);
	}

	if (pflag){
		memset(&hints, 0 , sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_DGRAM;
		hints.ai_flags =  AI_PASSIVE;
		error = getaddrinfo(NULL, optarg, &hints, &res);
		if (error!=0){
			err(1, "%s", gai_strerror(error));
		}
		myaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
	}else{
		myaddr.sin_port = htons(S_PORT);
	}
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	error = bind(mysocket,(struct sockaddr *) &myaddr, sizeof(myaddr));
	if ( error!=0){
		err(4,(char*)errno);
	}
	while (1){
		ipflag=1;
		clilen=sizeof(cliaddr);
		msglen=recvfrom(mysocket, msgbuff, MAXLEN, 0, (struct sockaddr *) &cliaddr, &clilen);
		if (msglen==-1){
		err(5,(char*)errno);
		}
		if (msglen==0){
			return 0;
		}else{
			printf("%s\n", msgbuff);
			memset(&hints,0,sizeof(hints));
			hints.ai_family=AF_INET;
			hints.ai_flags|=AI_CANONNAME;
			
			error=getaddrinfo(msgbuff, NULL, &hints, &res);
			if(error!=0){
				err(4,(char*)errno);
			}
			//ip
			i=0;
			while(msgbuff[i]!=0){
				if(!(msgbuff[i]>=48 && msgbuff[i]<=57) && msgbuff[i]!=46){
					ipflag=0;
					break;
				}
				i++;	
			}

			if (ipflag){
				error=getnameinfo(res->ai_addr, res->ai_addrlen, tempaddr, 100, NULL, 0, NI_DGRAM);
				if(error!=0){
					err(7,(char*)errno);
				} 
				
				strncat(msgbuff, " ", 1);
				strncat(msgbuff,tempaddr, strlen(tempaddr)); 
				
				
			}else{
				//cannon primljen
				inet_ntop(AF_INET, &(((struct sockaddr_in *)res->ai_addr)->sin_addr.s_addr), tempaddr, INET_ADDRSTRLEN);
				strncat(msgbuff," ", 1);
				strncat(msgbuff, tempaddr, strlen(tempaddr));
				
			}
			error=0;
			error=sendto(mysocket, msgbuff, strlen(msgbuff)+1, 0, (struct sockaddr *)&cliaddr, clilen);
			if(error==-1){
				err(5,(char*)errno);
			}
			
		}
	
	}
	
	return 0;
}
