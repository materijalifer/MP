
#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <getopt.h>
#include <sys/stat.h>
#include <errno.h>
#include <syslog.h>
#include <stdarg.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>

int Getaddrinfo(const char *hostname, const char *service, const struct addrinfo *hints, struct addrinfo **result) {
	int erro;
	
	erro = getaddrinfo(hostname, service, hints, result);
	if (erro<0){
		err(1, "%s", gai_strerror(erro));
	} else {
		return 0;
	}
}

int Write(int fd, char *buff, int num){
	int erro;
	erro = write(fd, buff, num);
	if(erro<0){
		err(1,"write error\n");
	}else{
		return 0;
	}
}

int Socket(int family, int type, int protocol){
	int n;
	if ((n=socket(family,type,protocol))==-1){
		err(1,"socket error\n");
	} else {
		return n;
	}
}

int Bind (int sockfd, const struct sockaddr *myaddr, int addrlen){
	int erro;
	erro=bind(sockfd, myaddr, addrlen);
	if (erro<0){
		err(1,"bind error\n");
	}else{
		return 0;
	}
}




ssize_t Recv(int s, void *buff, size_t len, int flags){
	int n;
	n = recv(s, buff, len, flags);
	if (n<0){
		err(1,"receve error\n");
	}else{
		return n;
	}
}

int Connect (int sockfd, const struct sockaddr *server, socklen_t addrlen){
	int erro;
	erro=connect(sockfd, server, addrlen);
	if (erro==-1){
		err(1,"connect error\n");
	} else {
		return 0;
	}
}

ssize_t Send(int s, const void *msg, size_t len, int flags){
	int n;
	n=send(s,msg,len,flags);
	if(n<0){
		err(1,"send error\n");
	}else{
		return n;
	}
}

ssize_t Sendto(int sockfd, void *buff, size_t nbytes, int flags, const struct sockaddr* to, socklen_t addrlen){
	int erro;
	erro= sendto(sockfd, buff, nbytes, flags, to, addrlen);
	if (erro<0){
		
		err(1,"sendto error\n");
		return -1;
		
	}else{
		return 0;
	} 
}

ssize_t Recvfrom(int sockfd, void *buff, size_t nbytes, int flags, struct sockaddr* from, socklen_t *fromaddrlen){
	
	int n;
	n=recvfrom(sockfd, buff, nbytes, flags, from, fromaddrlen);
	if (n<0){
		
		err(1,"recevefrom error\n");
		return -1;
		
	}else{
		return n;
	}
}


int main(int argc, char *argv[]){
	int pflag = 0;
	char msgbuff[1500];
	int udpSocket;
	int tcpSocket;
	struct addrinfo hints, *res, *servinfo;
	struct sockaddr_in cliaddr;
	socklen_t clilen;
	int options;
	
	if (argc!=1 && argc!=3){
		err(3,"Usage: ./tempserv [-p naziv_ili_broj_porta]");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./tempserv [-p naziv_ili_broj_porta]");
				break;
		}
	}
	memset(&hints, 0 , sizeof (hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags =  AI_PASSIVE;
	if (pflag){
		Getaddrinfo(NULL, optarg, &hints, &res);
	}else{
		Getaddrinfo(NULL, "1234", &hints, &res);
	}
	udpSocket = Socket(res->ai_family, res->ai_socktype, 0);
	
	Bind(udpSocket, res->ai_addr, res->ai_addrlen);
	
	memset(&hints, 0 , sizeof (hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags|=AI_CANONNAME;
	
	Getaddrinfo("m.pljusak.com", "http", &hints, &servinfo);
	
	
	
	
	
	while (1){
		tcpSocket = Socket(servinfo->ai_family, servinfo->ai_socktype, 0);
		Connect(tcpSocket, servinfo->ai_addr, servinfo->ai_addrlen);
		memset(msgbuff,0,1500);
		clilen=sizeof(cliaddr);
		Recvfrom(udpSocket, msgbuff, 1500, 0, (struct sockaddr *) &cliaddr, &clilen);
		//int krk=0;
		//int karlovac=0;
		//int maksimir=1;
		if (strlen(msgbuff)>3){
			
			Send(tcpSocket, "GET /mobile.php?stanica=", 24, 0);
			Send(tcpSocket, msgbuff, strlen(msgbuff)-1, 0);
			Send(tcpSocket, " HTTP/1.1\r\n", 11,0);
			Send(tcpSocket, "Host: m.pljusak.com\r\n", 21, 0);
			Send(tcpSocket, "Connection: close\r\n\r\n", 21, 0);
		} else {
			//maksimir=1;
			Send(tcpSocket, "GET /mobile.php?stanica=dhmz_maksimir HTTP/1.1\r\n", 48, 0);
			Send(tcpSocket, "Host: m.pljusak.com\r\n", 21, 0);
			Send(tcpSocket, "Connection: close\r\n\r\n", 21, 0);
		}
		//int k=0;
		char replybuff[1000];
		memset(replybuff,0,1000);
		int imaJos = 0;
		char reply[10000];
		int offset=0;
		do{
			offset=imaJos+offset;
			
			imaJos=Recv(tcpSocket, reply+offset, 10000, 0);
			
		}while(imaJos!=0);
		char *stanica;
		stanica=strstr(reply,"mobilestanica");
		stanica = stanica + 15;
		char *stanicaKraj;
		stanicaKraj=strstr(stanica, "</td>");
		*stanicaKraj='\0';
		strcpy(replybuff, stanica);
		*stanicaKraj = '<';
		char *temp;
		temp = strstr(reply,"temp");
		temp = temp + 6;
		char *tempKraj;
		tempKraj = strstr(temp, "</td>");
		*tempKraj = '\0';
		strcat(replybuff, temp);
		Sendto(udpSocket, replybuff, strlen(replybuff)+1, 0, (struct sockaddr *)&cliaddr, clilen);
		close(tcpSocket);
			
			
			
		
		
		
	}
	
}
