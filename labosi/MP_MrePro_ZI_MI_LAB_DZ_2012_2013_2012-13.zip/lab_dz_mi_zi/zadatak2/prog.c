#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>
#include<errno.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<err.h>
#include<string.h>


int Bind(int sockfd, const struct sockaddr *myaddr, int addrlen){
	int err;
	char *error;
	err = bind(sockfd, myaddr, addrlen);
	if(err==-1){
		error = strerror(errno);
		printf("%s\n", error);
		exit(4);
	} else {
		return 0;		
	}		
}
int Socket(int family, int type, int protocol){
	int n;
	char *error;
	if ((n=socket(family,type,protocol))==-1){
		error = strerror(errno);
		printf("%s\n",error);
		exit(4);
	} else {
		return n;
	}
}

int Getaddrinfo(const char *hostname, const char *service, const struct addrinfo *hints, struct addrinfo **result) {
	int err;
	char *error;
	err = getaddrinfo(hostname, service, hints, result);
	if (err){
		error = strerror(errno);
		printf("%s\n",error);
		exit(5);
	} else {
		return 0;
	}
}

int main(int argc, char *argv[]){
	int option, type, mysocket, uflag=0, xflag=0, nflag=0;
	char addrstr[200];
	struct sockaddr_in myaddr;
	struct servent *server;
	struct addrinfo hints, *result;
	
	if (argc <= 2 ) {
		printf("Usage: prog [-t|-u][-x][-h|-n] hostname servicename\n");
		return 3;
	}
	while((option = getopt(argc, argv, "xthun")) != -1) {
		switch(option){
			case 'u': 
				uflag=1;
				break;
			case 'x':
				xflag=1;
				break;
			case 'n':
				nflag=1;
				break;
			case 't':
				break;
			case 'h':
				break;
			default:
				printf("Usage: prog [-t|-u][-x][-h|-n] hostname servicename\n");
				return 3;
		}
	}
	if (argc - optind != 2) {
		printf("Usage: prog [-t|-u][-x][-h|-n] hostname servicename\n");
		return 3;
	}
	if (uflag){
		type=SOCK_DGRAM;
	} else {
		type=SOCK_STREAM;
	}
	mysocket=Socket(PF_INET, type,0);
	
	myaddr.sin_port=htons(0);
	myaddr.sin_family=AF_INET;
	myaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	Bind(mysocket, (struct sockaddr *) &myaddr, sizeof(myaddr));
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_flags = AI_CANONNAME;
	Getaddrinfo(argv[argc-2], argv[argc-1], &hints, &result);
	inet_ntop(result->ai_family, &((struct sockaddr_in *) result->ai_addr)->sin_addr, addrstr, INET_ADDRSTRLEN);
	
	if(uflag){
		server = getservbyname(argv[argc-1], "udp");
	} else {
		server = getservbyname(argv[argc-1], "tcp");
	}
	if (server==NULL){
		printf("prog: nodname nor servname provided, or not known\n");
		return 5;
	}
	if(nflag==0){
		server->s_port = ntohs(server->s_port);
	}
	if(xflag){
		printf("%s (%s) %04x\n", addrstr, result->ai_canonname, server->s_port);
	} else {
		printf("%s (%s) %d\n", addrstr, result->ai_canonname, server->s_port);
	}
	freeaddrinfo(result);
	close(mysocket);
	return 0;
}











