

#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <getopt.h>
#include <sys/stat.h>
#include <errno.h>
#include <syslog.h>
#include <stdarg.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>

int Getaddrinfo(const char *hostname, const char *service, const struct addrinfo *hints, struct addrinfo **result) {
	int erro;
	
	erro = getaddrinfo(hostname, service, hints, result);
	if (erro<0){
		err(1, "%s", gai_strerror(erro));
	} else {
		return 0;
	}
}

int Write(int fd, char *buff, int num){
	int erro;
	erro = write(fd, buff, num);
	if(erro<0){
		err(1,"write error\n");
	}else{
		return 0;
	}
}

int Socket(int family, int type, int protocol){
	int n;
	if ((n=socket(family,type,protocol))==-1){
		err(1,"socket error\n");
	} else {
		return n;
	}
}

int Bind (int sockfd, const struct sockaddr *myaddr, int addrlen){
	int erro;
	erro=bind(sockfd, myaddr, addrlen);
	if (erro<0){
		err(1,"bind error\n");
	}else{
		return 0;
	}
}

int Listen(int sockfd, int backlog){
	int erro;
	erro=listen(sockfd, backlog);
	if (erro<0){
		err(1,"listen error\n");
	}else{
		return 0;
	}
}

int Accept(int sockfd, struct sockaddr* cliaddr, socklen_t *addrlen){
	int n;
	n=accept(sockfd, cliaddr, addrlen);
	if(n<0){
		err(1,"accept error\n");
	}else{
		return n;
	}
}

ssize_t Recv(int s, void *buff, size_t len, int flags){
	int n;
	n = recv(s, buff, len, flags);
	if (n<0){
		err(1,"receve error\n");
	}else{
		return n;
	}
}

int Connect (int sockfd, const struct sockaddr *server, socklen_t addrlen){
	int erro;
	erro=connect(sockfd, server, addrlen);
	if (erro==-1){
		err(1,"connect error\n");
	} else {
		return 0;
	}
}

ssize_t Send(int s, const void *msg, size_t len, int flags){
	int n;
	n=send(s,msg,len,flags);
	if(n<0){
		err(1,"send error\n");
	}else{
		return n;
	}
}
// host oblika: www.nesto.com
void getHost(char *msgbuff, char *host, int offset){
	int k = 0;
	while (*(msgbuff+offset) != ' '){
		*(host+k) = *(msgbuff+offset);
		offset++;
		k++;
	}
	*(host+k) = '\0';
}

int checkRequest(char *msgbuff, char *req, char *host){
	int i=0;
	while (*(msgbuff + i) != ' '){
		*(req+i) = *(msgbuff + i);
		i++;
	}
	*(req+i)='\0';
	getHost(msgbuff, host, i+1);
	if (strcmp(req, "GET")){
		return 0;
	}else{
		return 1;
	}
}

int main(int argc, char *argv[]){
	int cflag = 0;
	int listenSocket;
	int ansSocket;
	int reqSocket;
	char msgbuff[15000];
	int msglen;
	struct addrinfo hints, *res, *server;
	int options;
	//int error;
	pid_t pid;
	struct sockaddr_in cliaddr;
	socklen_t clilen;
	FILE *f;
	struct stat info;
	
	
	if (argc<=1){
		printf("Usage: ./proxy_cashe [--cache] port [filter]\n");
		return -1;
	}
	struct option long_options[] = {{"cache", no_argument, 0, 0}};
	int pos = 0;
	while ((options = getopt_long(argc, argv, "", long_options, &pos)) != -1){
		switch (options){
			case 0:
				cflag = 1;
				break;
			default:
				printf("Usage: ./proxy_cashe [--cache] port [filter]\n");
				return -1;	
		}
	}
	
	if (argc - cflag - 1 < -1){
		printf("Usage: ./proxy_cashe [--cache] port [filter]\n");
		return -1;	
	}
	
	int brFiltera = 0;
	// prebrojavanje filtriranih adresa, ako ih ima
	if (argc-2-cflag >=1){
		brFiltera = argc-2-cflag;
	}
	
	memset(&hints, 0 , sizeof (hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags|=AI_CANONNAME;
	
	Getaddrinfo(NULL, argv[cflag+1], &hints, &res);
	
	listenSocket = Socket(res->ai_family, res->ai_socktype, 0);
	
	Bind(listenSocket, res->ai_addr, res->ai_addrlen);
	
	Listen(listenSocket, 1);
	
	while(1) {
		clilen=sizeof(cliaddr);
		ansSocket = Accept(listenSocket,(struct sockaddr *)&cliaddr, &clilen);
		// dijete pocinje
		if((pid=fork())==0){
			msglen = Recv(ansSocket, msgbuff, 15000, 0);
			// provjeri request
			char req[8];
			char host[100];
			//char adresa[20];
			if (checkRequest(msgbuff, req, host) == 0){
				
				//adresa = inet_ntoa(cliaddr.sin_addr);
				printf("%s: KRIVO %s %s \n", inet_ntoa(cliaddr.sin_addr), req, host);
				Send (ansSocket, "HTTP/1.1 405 Method Not Allowed\r\n\r\n", 40, 0);
				return -2;
			}
			
			// dobar tip zahtjeva
			// da li je adresa medu filtriranima?
			
			int i;
			for (i=0; i<brFiltera; i++){
				// ako je u listi iz argv-a
				// strstr vraca null ako nije nasao
				if (strstr(host, argv[i+cflag+2]) != NULL){
					//adresa = inet_ntoa(cliaddr.sin_addr);
					printf("%s: FILTRIRANO: %s %s \n", inet_ntoa(cliaddr.sin_addr), req, host);
					Send(ansSocket, "HTTP/1.1 403 Forbidden\r\n\r\n <p>Forbidden</p>\r\n", 45, 0); 
					close(ansSocket);
					return -1;
				}
			}
			// u varijabli zahtjev = www.nesto.com/nesto
			char zahtjev[500];
			strcpy(zahtjev, host);
			// trebamo maknuti www
			//hostName samo ime hosta bez www
			char *hostName;
			//pozicioniraj se na pocetak imena
			hostName = (strstr(host, "www"));
			// host = www.nesto.com/ , kasnije petljam po memoriji na toj poziciji
			//maknuti / s kraja
			char *temp;
			temp=strchr(hostName,'/');
			*temp='\0';
			// u varijabli hostName=www.nesto.com
			
			
			// implementirati cache
			
			if(cflag){
				// u filecache stavljam ime file-a u cacheu. 
				char filecache[500];
				strcpy(filecache,zahtjev+7);
				for (i=0; i<strlen(filecache); i++){
					if (filecache[i]=='/'){
						filecache[i]='_';
					}
				}
				f = fopen(filecache, "rb");
				if (f == NULL) {
					//printf("File nije u cache-u\n");
				} else {
					//printf("File dohvacen iz cache-a\n");
					fstat(fileno(f), &info);
					char *filebuffer;
					filebuffer = malloc(info.st_size);
					fread(filebuffer, 1, info.st_size, f);
					Write(ansSocket, filebuffer, info.st_size +1);
					// poslan file, kraj rada
					printf("%s: %s %s\n", inet_ntoa(cliaddr.sin_addr), req, zahtjev);
					fclose(f);
					close(ansSocket);
					return 0;
				}
			}
			
			// spoji se na pravi server
			
			memset(&hints, 0 , sizeof (hints));
			hints.ai_family = AF_INET;
			hints.ai_socktype = SOCK_STREAM;
			hints.ai_flags|=AI_CANONNAME;
			Getaddrinfo(hostName, "http", &hints, &server);
			reqSocket=Socket(server->ai_family, server->ai_socktype, 0);
			Connect(reqSocket, server->ai_addr, server->ai_addrlen);
			// spojen na pravi server
			//adresa=inet_ntoa(cliaddr.sin_addr);
			printf("%s: %s %s\n", inet_ntoa(cliaddr.sin_addr), req, zahtjev);
			char *tempchar;
			tempchar=msgbuff;
			// reqbuff = ono kaj šaljem na pravi server. cjeli msg buff bez http://...
			char reqbuff[15000];
			memset(reqbuff, 0, 15000);
			// tempchar: cijeli zahtjev početno od /
			tempchar = tempchar + 11 + strlen(hostName);
			strcpy(reqbuff,"GET ");
			strcat(reqbuff, tempchar);  
			
			Send(reqSocket, reqbuff, strlen(reqbuff), 0);
			
			// pripremi file za spremanje u chache ako je cflag ukljucen
			if (cflag){
				char filecache[500];
				strcpy(filecache,zahtjev+7);
				for (i=0; i<strlen(filecache); i++){
					if (filecache[i]=='/'){
						filecache[i]='_';
					}
				}
				//printf("%s\n", filecache); 
				f=fopen(filecache, "wb+");
				if (f==NULL){
					perror("can not open file\n");
				}
			}
			int imaJos = 1;
			char reply;
			//char reply[1500];
			while (imaJos>0){
				imaJos=Recv(reqSocket, &reply, 1, 0);
				Send(ansSocket, &reply, 1, 0);
				//ako ima cflag, zapisi u chache
				if(cflag){
					//i=0;
					//while(i<imaJos){
						//fprintf(f,"%c", reply[i]);
						//i++;
					//}
					//memset(reply,0,1500);
					fprintf(f,"%c",reply);
				}
			}
			if(cflag){
				fclose(f);
			}
			close(ansSocket);
			close(reqSocket);
			return 0;
			//kraj djeteta
			
		}
		
		
		// roditelj
		close(ansSocket);
	
	}
	
	return 0;
}
