
#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sys/stat.h>
#include <errno.h>
#include <syslog.h>
#include <stdarg.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#define PORT 1234
#define MAXLEN 1400


int Getaddrinfo(const char *hostname, const char *service, const struct addrinfo *hints, struct addrinfo **result) {
	int err;
	char *error;
	err = getaddrinfo(hostname, service, hints, result);
	if (err){
		error = strerror(errno);
		printf("%s\n",error);
		exit(5);
	} else {
		return 0;
	}
}

ssize_t readn(int fd, void *vptr, size_t n){
	
	size_t nleft;
	size_t nread;
	char *ptr;
	
	ptr = vptr;
	nleft = n;
	
	while (nleft >0){
		if( (nread = read(fd, ptr, nleft))<0){
			if (errno == EINTR)
				nread = 0;
			else
				return (-1);
		} else if (nread == 0)
					break;
		nleft -= nread;
		ptr += nread;
	}
	return (n-nleft); 			
} 

int deamon_init(const char *pname, int facility){
	int i;
	pid_t pid;
	
	if ((pid = fork()) < 0)
		return (-1);
	else if (pid)
		_exit(0);
	
	if (setsid() < 0)
		return (-1);
	
	signal (SIGHUP, SIG_IGN);
	
	if ((pid = fork())< 0 )
		return (-1);	
	else if (pid)
		_exit(0);
	// chdir ("/");
	
	for (i=0; i<64; i++)
		close (i);
	
	open("/dev/null", O_RDONLY);
	open("/dev/null", O_RDWR);
	open("/dev/null", O_RDWR);	
	
	openlog("MrePro tcpserver", LOG_PID, LOG_FTP);
	return 0;
}


int main (int argc, char *argv[]){
	int pflag = 0;
	int mysocket;
	int newsocket;
	struct sockaddr_in myaddr, cliaddr;
	socklen_t servlen;
	char msgbuff[MAXLEN];
	struct addrinfo hints, *res;
	int options;
	int error;
	pid_t pid;
	
	
	
	if (argc!=1 && argc!=3){
		err(3,"Usage: ./tcpserver [-p port]\n");
	}
	while ((options = getopt(argc, argv, "p:")) != -1){
		switch (options){
			case 'p':
				pflag = 1;
				break;
			default:
				err(3,"Usage: ./tcpserver [-p port]\n");
				break;
		}
	}
	
	if (pflag){
		memset(&hints, 0 , sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags |= AI_CANONNAME;
		Getaddrinfo(NULL, optarg, &hints, &res);
		myaddr.sin_port = ((struct sockaddr_in *)res->ai_addr)->sin_port;
	}else{
		myaddr.sin_port = htons(PORT);
	}
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	memset(myaddr.sin_zero, '\0', sizeof(myaddr.sin_zero));
	
	deamon_init(argv[0], 0);
	
	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	if (mysocket == -1) {
		syslog(LOG_ALERT, "Greska: Socket\n");
		return -1;
	}
	
	error = bind(mysocket,(struct sockaddr *) &myaddr, sizeof(myaddr));
	if ( error!=0){
		syslog(LOG_ALERT, "Greska: Bind error\n");
		return -1;
	}
	
	error = listen(mysocket,1);
	if (error == -1){
		syslog(LOG_ALERT, "Greska:listen error\n");
		return -1;
	}
	while (1){
		servlen = sizeof (cliaddr);
		newsocket=accept(mysocket, (struct sockaddr *)&cliaddr, &servlen);
		if (newsocket == -1){
			syslog(LOG_ALERT, "Greska: accept error\n");
			continue;
		}
		if ((pid = fork()) == 0) {
			FILE *f;
			uint32_t pomak = 0;
			uint32_t vrijeme = 0;
			uint32_t myvrijeme = 0;
			uint8_t status;
			ssize_t recvlen;
			struct stat fileStat;
			char *adresa;
			char filebuffer[MAXLEN];
			

			printf("usao u dijete\n");
			close(mysocket);
			
			error = readn(newsocket, &pomak, 4);
			if (error==-1){
				syslog(LOG_ALERT, "Greska: readn\n");
				close(newsocket);
				continue;
			}
			pomak = ntohl(pomak);
			error = readn(newsocket, &vrijeme, 4);
			if (error ==-1){
				printf("usao u error, vrijeme\n");
				syslog(LOG_ALERT, "Greska: readn\n");
				close(newsocket);
				continue;
			}
			vrijeme = ntohl(vrijeme);
			recvlen = recv(newsocket, msgbuff, sizeof(msgbuff), 0);
			if (recvlen == -1) {
				syslog(LOG_ALERT, "Greska: receve\n");
				close(newsocket);
				continue;
			}
			
			if (strchr(msgbuff, '/')){
				syslog(LOG_ALERT, "Greska: file izvan trenutnog foldera\n");
				status = 6;
				error = send(newsocket, &status, sizeof(uint8_t) ,0);
				if (error <0){
					syslog(LOG_ALERT, "Greska: send, status: not in current folder\n");
					close(newsocket);
				}
				close(newsocket);
				continue;
			}
			f = fopen(msgbuff, "rb");
			if (f == NULL){
				syslog(LOG_ALERT, "Greska: file ne postoji\n");
				status = 9;
				error = send(newsocket, &status, sizeof(uint8_t) ,0);
				if (error <0){
					syslog(LOG_ALERT, "Greska: send, status:not found\n");
					close(newsocket);
				}
				close(newsocket);
				continue;
			}
			stat(msgbuff, &fileStat);
			int ftime = (int) fileStat.st_mtime;
			myvrijeme = (uint32_t) ftime;
			
			if(myvrijeme<=vrijeme){
				syslog(LOG_ALERT, "Greska: file up to date\n");
				status = 103;
				error = send(newsocket, &status, sizeof(uint8_t) ,0);
				if (error <0){
					syslog(LOG_ALERT, "Greska: send, status:up to date\n");
					close(newsocket);
				}
				close(newsocket);
				continue;
			} else {
				inet_ntop(AF_INET, &(cliaddr.sin_addr), adresa, INET_ADDRSTRLEN);
				syslog(LOG_INFO, "Klijentu %s poslan %s:%d, %d", adresa, msgbuff, pomak, myvrijeme);
				status = 204;
				error = send(newsocket, &status, sizeof(uint8_t) ,0);
				if (error <0){
					syslog(LOG_ALERT, "Greska: send, status:ok\n");
					close(newsocket);
					continue;
				}
				fseek(f, pomak,SEEK_SET);
				while(!feof(f)){
					memset(filebuffer, '\0', sizeof(filebuffer));
					int procitano = fread (filebuffer, sizeof (char), MAXLEN, f);
					if (procitano < 0 ) {
						syslog(LOG_ALERT, "Greska: fread()\n");
						break;
					}
					error = send(newsocket, filebuffer, (sizeof (char))*procitano, 0);
					if (error <0){
						syslog(LOG_ALERT, "Greska: send file\n");
						break;
					}
				}
				
			}
			close(newsocket);
			fclose(f);
			
			
			
		}
		close(newsocket);
	}
	
	return 0;
}
