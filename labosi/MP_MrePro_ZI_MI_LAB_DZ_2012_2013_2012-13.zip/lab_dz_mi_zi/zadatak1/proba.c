#include <stdio.h>
#include "proba.h"
int main() {
	printf("Dobar dan %s\n",LOGIN);
	return 0;
}

